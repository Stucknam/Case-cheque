const cameraArea = document.getElementById('cameraArea'); 
const video = document.getElementById('cameraView');
const placeholderText = document.getElementById('placeholderText');
const captureBtn = document.getElementById('captureBtn');
const flipBtn = document.getElementById('flipBtn');
const canvas = document.getElementById('snapshot');
const galleryBtn = document.getElementById('galleryBtn');
const uploadInput = document.getElementById('uploadInput');

let stream = null;
let usingFrontCamera = false;

async function startCamera() {
  if (stream) {
    stream.getTracks().forEach(track => track.stop());
  }

  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: {
        facingMode: usingFrontCamera ? 'user' : 'environment'
      },
      audio: false
    });

    video.srcObject = stream;
    video.style.display = 'block';
    placeholderText.style.display = 'none';
  } catch (err) {
    alert('Не удалось получить доступ к камере: ' + err.message);
  }
}

cameraArea.addEventListener('click', startCamera);

flipBtn.addEventListener('click', () => {
  usingFrontCamera = !usingFrontCamera;
  startCamera();
});

captureBtn.onclick = () => {
  if (!stream) return alert('Сначала включите камеру!');

  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  canvas.getContext('2d').drawImage(video, 0, 0);

  canvas.toBlob(blob => {
    const formData = new FormData();
    formData.append('image', blob, 'receipt.jpg');

    fetch('/scan', {
      method: 'POST',
      body: formData
    })
    .then(res => res.json())
    .then(data => {
      localStorage.setItem('receiptText', data.text);
      localStorage.setItem('receiptItems', JSON.stringify(data.items)); 
      console.log('Сохранены товары:', data.items);
      window.location.href = 'results.html';
    })
    .catch(err => alert('Ошибка при сканировании: ' + err));
  }, 'image/jpeg');
};

galleryBtn.addEventListener('click', () => {
  uploadInput.click();
});

uploadInput.addEventListener('change', () => {
  const file = uploadInput.files[0];
  if (!file) return;

  const formData = new FormData();
  formData.append('image', file, 'receipt.jpg');

  fetch('/scan', {
    method: 'POST',
    body: formData
  })
    .then(res => res.json())
    .then(data => {
      localStorage.setItem('receiptText', data.text);
      localStorage.setItem('receiptItems', JSON.stringify(data.items));
      console.log('Сохранены товары:', data.items); 
      window.location.href = 'results.html';
    })
    .catch(err => alert('Ошибка при загрузке: ' + err));
});
